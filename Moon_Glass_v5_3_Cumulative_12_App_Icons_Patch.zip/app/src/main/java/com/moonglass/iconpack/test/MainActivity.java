package com.moonglass.iconpack.test;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.WallpaperManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;

public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(11, 20, 45);
    private static final int FG = Color.rgb(238, 244, 255);
    private static final int MUTED = Color.rgb(166, 185, 224);
    private static final int[] ICONS = new int[] {R.drawable.mg_01_phone,
        R.drawable.mg_02_messages,
        R.drawable.mg_03_camera,
        R.drawable.mg_04_gallery,
        R.drawable.mg_05_music,
        R.drawable.mg_06_browser,
        R.drawable.mg_07_settings,
        R.drawable.mg_08_calendar,
        R.drawable.mg_09_mail,
        R.drawable.mg_10_maps,
        R.drawable.mg_11_weather,
        R.drawable.mg_12_files,
        R.drawable.mg_13_clock,
        R.drawable.mg_14_calculator,
        R.drawable.mg_15_contacts,
        R.drawable.mg_16_notes,
        R.drawable.mg_17_alarm,
        R.drawable.mg_18_downloads,
        R.drawable.mg_19_video,
        R.drawable.mg_20_shopping,
        R.drawable.mg_21_flashlight,
        R.drawable.mg_22_recorder,
        R.drawable.mg_23_compass,
        R.drawable.mg_24_books,
        R.drawable.mg_25_tasks,
        R.drawable.mg_26_wallet,
        R.drawable.mg_27_security,
        R.drawable.mg_28_wireless,
        R.drawable.mg_29_battery,
        R.drawable.mg_30_fitness,
        R.drawable.mg_31_call_log,
        R.drawable.mg_32_todo,
        R.drawable.mg_33_folder_open,
        R.drawable.mg_34_search,
        R.drawable.mg_35_photo_edit,
        R.drawable.mg_36_battery,
        R.drawable.mg_37_wifi,
        R.drawable.mg_38_connection,
        R.drawable.mg_39_wallet,
        R.drawable.mg_40_shopping_cart,
        R.drawable.mg_41_youtube_moon,
        R.drawable.mg_42_netflix_moon,
        R.drawable.mg_43_tiktok_moon,
        R.drawable.mg_44_whatsapp_moon,
        R.drawable.mg_45_discord_moon,
        R.drawable.mg_46_play_store_moon,
        R.drawable.mg_47_galaxy_store_moon,
        R.drawable.mg_48_docs_moon,
        R.drawable.mg_49_instagram_moon,
        R.drawable.mg_50_spotify_moon,
        R.drawable.mg_51_telegram_moon,
        R.drawable.mg_52_gmail_moon};
    private static final String[] NAMES = new String[] {"Phone",
        "Messages",
        "Camera",
        "Gallery",
        "Music",
        "Browser",
        "Settings",
        "Calendar",
        "Mail",
        "Maps",
        "Weather",
        "Files",
        "Clock",
        "Calculator",
        "Contacts",
        "Notes",
        "Alarm",
        "Downloads",
        "Video",
        "Shopping",
        "Flashlight",
        "Recorder",
        "Compass",
        "Books",
        "Tasks",
        "Wallet",
        "Security",
        "Wireless",
        "Battery",
        "Fitness",
        "Call Log",
        "Todo",
        "Folder Open",
        "Search",
        "Photo Edit",
        "Battery",
        "Wifi",
        "Connection",
        "Wallet",
        "Shopping Cart",
        "YouTube",
        "Netflix",
        "TikTok",
        "WhatsApp",
        "Discord",
        "Play Store",
        "Galaxy Store",
        "Google Docs",
        "Instagram",
        "Spotify",
        "Telegram",
        "Gmail"};

    private int dp(float value) { return (int)(getResources().getDisplayMetrics().density * value + .5f); }
    private TextView text(String value, int size, int color) {
        TextView v = new TextView(this);
        v.setText(value); v.setTextSize(size); v.setTextColor(color);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }
    private LinearLayout.LayoutParams params(int width, int height) { return new LinearLayout.LayoutParams(width, height); }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(dp(18),dp(20),dp(18),dp(30));
        scroll.addView(main);
        TextView title = text("Moon Glass", 32, FG);
        title.setTypeface(Typeface.SERIF, Typeface.NORMAL);
        main.addView(title);
        main.addView(text("GALAXY ICON PACK · TEST BUILD", 12, MUTED));
        addGap(main, 15);
        TextView info = text("52개 테스트 아이콘 · 배경화면 2장\n갤럭시: Good Lock → Theme Park → 아이콘 → 새로 만들기 → 아이콘팩에서 Moon Glass 선택. 기기에 따라 지원 여부와 자동 매핑이 다릅니다.", 14, FG);
        info.setLineSpacing(dp(3),1f);
        main.addView(info);
        addGap(main,20);
        main.addView(text("WALLPAPERS",18,FG));
        addGap(main,8);
        wallpaper(main,"MOON LAKE","wallpapers/moon_lake.png");
        wallpaper(main,"DREAM CLOUDS","wallpapers/dream_clouds.png");
        addGap(main,16);
        main.addView(text("ICONS  ·  52 TEST FILES",18,FG));
        main.addView(text("일부는 동일 기능의 대체 디자인입니다. 모든 앱 자동 적용을 보장하지 않습니다.",12,MUTED));
        addGap(main,12);
        GridView grid = new GridView(this);
        grid.setNumColumns(4);
        grid.setHorizontalSpacing(dp(5));
        grid.setVerticalSpacing(dp(8));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(android.R.color.transparent);
        grid.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return ICONS.length; }
            @Override public Object getItem(int position) { return NAMES[position]; }
            @Override public long getItemId(int position) { return position; }
            @Override public View getView(int position,View convertView,ViewGroup parent) {
                LinearLayout cell = new LinearLayout(MainActivity.this);
                cell.setGravity(Gravity.CENTER);
                cell.setOrientation(LinearLayout.VERTICAL);
                ImageView image = new ImageView(MainActivity.this);
                image.setImageResource(ICONS[position]);
                image.setScaleType(ImageView.ScaleType.FIT_CENTER);
                cell.addView(image, params(dp(67),dp(67)));
                TextView label = text(NAMES[position],10,MUTED);
                label.setGravity(Gravity.CENTER);
                label.setMaxLines(2);
                cell.addView(label,params(ViewGroup.LayoutParams.MATCH_PARENT,dp(33)));
                return cell;
            }
        });
        int rows=(ICONS.length+3)/4;
        main.addView(grid,params(ViewGroup.LayoutParams.MATCH_PARENT,dp(rows*109)));
        main.addView(text("TEST ONLY · 실기기 아이콘 매핑과 판매용 화질은 미검증",12,MUTED));
        setContentView(scroll);
    }
    private void addGap(LinearLayout parent,int h) {
        View v=new View(this); parent.addView(v,params(1,dp(h)));
    }
    private void wallpaper(LinearLayout parent, String title,String filename) {
        TextView label=text(title,14,FG);
        parent.addView(label);
        ImageView image=new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        try(InputStream stream=getAssets().open(filename)) {
            image.setImageDrawable(Drawable.createFromStream(stream,null));
        } catch(Exception e) { image.setBackgroundColor(Color.DKGRAY); }
        LinearLayout.LayoutParams p=params(ViewGroup.LayoutParams.MATCH_PARENT,dp(175));
        p.topMargin=dp(7);
        parent.addView(image,p);
        Button button=new Button(this);
        button.setText(title+" · 배경화면 적용");
        button.setAllCaps(false);
        button.setOnClickListener(v->confirmWallpaper(filename));
        parent.addView(button,params(ViewGroup.LayoutParams.MATCH_PARENT,dp(48)));
        addGap(parent,10);
    }
    private void confirmWallpaper(String filename) {
        final String[] choices={"홈 화면", "잠금 화면"};
        new AlertDialog.Builder(this)
            .setTitle("배경화면 적용 위치")
            .setItems(choices,(dialog,which)->new AlertDialog.Builder(this)
                 .setTitle("배경화면 변경")
                 .setMessage(choices[which]+" 배경화면을 Moon Glass 이미지로 변경할까요? 기존 배경화면이 바뀝니다.")
                 .setNegativeButton("취소",null)
                 .setPositiveButton("적용",(d,w)->applyWallpaper(filename,which==0))
                 .show())
            .show();
    }
    private void applyWallpaper(String filename,boolean home) {
        try(InputStream stream=getAssets().open(filename)) {
            Bitmap bmp=BitmapFactory.decodeStream(stream);
            if(bmp==null)throw new IllegalStateException("이미지를 불러오지 못했습니다.");
            WallpaperManager manager=WallpaperManager.getInstance(this);
            if(Build.VERSION.SDK_INT>=24) manager.setBitmap(bmp,null,true,home?WallpaperManager.FLAG_SYSTEM:WallpaperManager.FLAG_LOCK);
            else manager.setBitmap(bmp);
            bmp.recycle();
            Toast.makeText(this,"배경화면 적용 완료",Toast.LENGTH_SHORT).show();
        }catch(Exception ex){
            new AlertDialog.Builder(this).setTitle("적용 실패").setMessage(ex.getMessage()).setPositiveButton("확인",null).show();
        }
    }
}
