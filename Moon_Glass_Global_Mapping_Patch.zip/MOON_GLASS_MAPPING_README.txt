Moon Glass — appfilter mapping patch (Galaxy + basic global)
=============================================================
1. Upload this ZIP to the ROOT of sk888sk9999-cpu/moon-glass-test.
2. In .github/workflows/build-from-upload.yml, directly AFTER the existing sed -i line
   and BEFORE python3 tools/check_assets.py, add exactly:
          unzip -o -q Moon_Glass_Global_Mapping_Patch.zip
3. Commit the workflow edit. GitHub Actions builds an updated test APK.

Included: original 26 mappings + verified A. Dot Dialer entry and Samsung/Google/AOSP
Contacts & Calculator variants, plus Google Play Store using the existing generic
shopping-bag symbol. No brand logos or new imagery are included in this patch.
Candidate activities differ across handset/OS/app versions; actual icon application
must be checked on a device. This is NOT a completed commercial/global icon pack.
The appfilter is duplicated in res/xml and assets as required by the source project.
