"""Moon Glass v5.5: static checks for the cumulative v5.5 mapping expansion."""
from pathlib import Path
from xml.etree import ElementTree as ET
import struct, re
root = Path(__file__).resolve().parents[1]
icons = sorted((root/'app/src/main/res/drawable-nodpi').glob('mg_*.png'))
assert len(icons) == 102, f'Expected 102 icons, found {len(icons)}'
for icon in icons:
    data = icon.read_bytes()
    assert data[:8] == b'\x89PNG\r\n\x1a\n', f'Not a PNG: {icon}'
    w,h,depth,color = struct.unpack('>IIBB',data[16:26])
    assert (w,h,depth,color) == (1024,1024,8,6), (icon,w,h,depth,color)
known = {icon.stem for icon in icons}
assert len(known) == 102
for base in ('app/src/main/res/xml/','app/src/main/assets/'):
    catalogue=ET.parse(root/base/'drawable.xml').getroot()
    items=catalogue.findall('item')
    drawings=[item.attrib['drawable'] for item in items]
    assert len(drawings) == 102 and set(drawings) == known, ('catalogue',base)
    filt=ET.parse(root/base/'appfilter.xml').getroot()
    entries=filt.findall('item')
    assert len(entries) == 127, ('launcher count',base,len(entries))
    comps=[item.attrib['component'] for item in entries]
    assert len(comps) == len(set(comps)), ('duplicate components',base)
    for item in entries:
        assert item.attrib['drawable'] in known, item.attrib
        assert item.attrib['component'].startswith('ComponentInfo{'), item.attrib
assert (root/'app/src/main/res/xml/appfilter.xml').read_bytes() == (root/'app/src/main/assets/appfilter.xml').read_bytes()
assert (root/'app/src/main/res/xml/drawable.xml').read_bytes() == (root/'app/src/main/assets/drawable.xml').read_bytes()
main = (root/'app/src/main/java/com/moonglass/iconpack/test/MainActivity.java').read_text(encoding='utf-8')
gallery=re.findall(r'R\.drawable\.(mg_[a-z0-9_]+)',main)
assert len(gallery) == 102 and set(gallery) == known, ('gallery mismatch',len(gallery))
required={
 'com.skt.prod.dialer':'mg_01_phone',
 'word.office.docxviewer.document.docx.reader':'mg_16_notes',
 'com.google.android.googlequicksearchbox':'mg_34_search',
 'com.samsung.android.oneconnect':'mg_38_connection',
 'com.google.android.youtube':'mg_41_youtube_moon',
 'com.netflix.mediaclient':'mg_42_netflix_moon',
 'com.zhiliaoapp.musically':'mg_43_tiktok_moon',
 'com.whatsapp':'mg_44_whatsapp_moon',
 'com.discord':'mg_45_discord_moon',
 'com.android.vending':'mg_46_play_store_moon',
 'com.sec.android.app.samsungapps':'mg_47_galaxy_store_moon',
 'com.google.android.apps.docs.editors.docs':'mg_48_docs_moon',
 'com.google.android.gm':'mg_52_gmail_moon',
 'org.telegram.messenger':'mg_51_telegram_moon',
 'com.spotify.music':'mg_50_spotify_moon',
 'com.instagram.android':'mg_49_instagram_moon',
 'com.android.chrome':'mg_53_chrome_moon',
 'com.google.android.apps.maps':'mg_54_google_maps_moon',
 'com.google.android.apps.photos':'mg_55_google_photos_moon',
 'com.google.android.apps.docs':'mg_56_google_drive_moon',
 'com.google.android.apps.docs.editors.sheets':'mg_57_google_sheets_moon',
 'com.google.android.apps.docs.editors.slides':'mg_58_google_slides_moon',
 'com.google.android.apps.youtube.music':'mg_59_youtube_music_moon',
 'com.google.android.apps.youtube.creator':'mg_60_youtube_studio_moon',
 'com.google.android.keep':'mg_61_google_keep_moon',
 'com.google.android.calendar':'mg_62_google_calendar_moon',
 'com.google.android.apps.walletnfcrel':'mg_63_google_wallet_moon',
 'com.google.android.apps.nbu.files':'mg_64_files_google_moon',
 'com.google.android.apps.tasks':'mg_65_google_tasks_moon',
 'com.google.android.apps.books':'mg_66_google_play_books_moon',
 'com.google.android.apps.tachyon':'mg_67_google_meet_moon',
 'com.microsoft.office.word':'mg_68_microsoft_word_moon',
 'com.microsoft.office.excel':'mg_69_microsoft_excel_moon',
 'com.microsoft.office.powerpoint':'mg_70_microsoft_powerpoint_moon',
 'com.microsoft.skydrive':'mg_71_microsoft_onedrive_moon',
 'com.microsoft.office.onenote':'mg_72_microsoft_onenote_moon',
 'com.microsoft.office.officehubrow':'mg_73_microsoft_365_moon',
 'com.facebook.orca':'mg_74_messenger_moon',
 'com.snapchat.android':'mg_75_snapchat_moon',
 'com.amazon.mShop.android.shopping':'mg_76_amazon_shopping_moon',
 'us.zoom.videomeetings':'mg_77_zoom_moon',
 'org.mozilla.firefox':'mg_92_firefox_moon',
 'com.microsoft.emmx':'mg_93_edge_moon',
 'com.brave.browser':'mg_94_brave_moon',
 'com.apple.android.music':'mg_95_apple_music_moon',
 'cn.wps.moffice_eng':'mg_96_wps_office_moon',
 'com.facebook.katana':'mg_78_facebook_moon',
 'com.instagram.barcelona':'mg_79_threads_moon',
 'com.twitter.android':'mg_80_x_moon',
 'com.reddit.frontpage':'mg_81_reddit_moon',
 'com.pinterest':'mg_82_pinterest_moon',
 'tv.twitch.android.app':'mg_83_twitch_moon',
 'com.linkedin.android':'mg_84_linkedin_moon',
 'com.Slack':'mg_85_slack_moon',
 'notion.id':'mg_86_notion_moon',
 'com.canva.editor':'mg_87_canva_moon',
 'com.lemon.lvoverseas':'mg_88_capcut_moon',
 'com.adobe.reader':'mg_89_adobe_acrobat_moon',
 'com.dropbox.android':'mg_90_dropbox_moon',
 'com.google.android.apps.translate':'mg_91_google_translate_moon',
 'com.ubercab':'mg_97_uber_moon',
 'com.airbnb.android':'mg_98_airbnb_moon',
 'com.paypal.android.p2pmobile':'mg_99_paypal_moon',
 'com.ebay.mobile':'mg_100_ebay_moon',
 'com.duolingo':'mg_101_duolingo_moon',
 'org.thoughtcrime.securesms':'mg_102_signal_moon',
}
filt=ET.parse(root/'app/src/main/res/xml/appfilter.xml').getroot()
for pkg,icon in required.items():
    assert any(item.attrib['component'].startswith('ComponentInfo{'+pkg+'/') and item.attrib['drawable']==icon for item in filt.findall('item')),('missing mapping',pkg,icon)

expected_additional = {
 'ComponentInfo{com.facebook.katana/com.facebook.katana.LoginActivity}': 'mg_78_facebook_moon',
 'ComponentInfo{com.facebook.katana/com.facebook.katana.MainActivity}': 'mg_78_facebook_moon',
 'ComponentInfo{com.instagram.barcelona/com.instagram.barcelona.mainactivity.BarcelonaActivity}': 'mg_79_threads_moon',
 'ComponentInfo{com.twitter.android/com.twitter.android.StartActivity}': 'mg_80_x_moon',
 'ComponentInfo{com.twitter.android/com.twitter.android.LoginActivity}': 'mg_80_x_moon',
 'ComponentInfo{com.reddit.frontpage/com.reddit.frontpage.StartActivity}': 'mg_81_reddit_moon',
 'ComponentInfo{com.reddit.frontpage/launcher.default}': 'mg_81_reddit_moon',
 'ComponentInfo{com.reddit.frontpage/launcher.doge}': 'mg_81_reddit_moon',
 'ComponentInfo{com.pinterest/com.pinterest.activity.PinterestActivity}': 'mg_82_pinterest_moon',
 'ComponentInfo{tv.twitch.android.app/tv.twitch.android.app.core.LandingActivity}': 'mg_83_twitch_moon',
 'ComponentInfo{com.linkedin.android/com.linkedin.android.authenticator.LaunchActivity}': 'mg_84_linkedin_moon',
 'ComponentInfo{com.Slack/com.Slack.ui.HomeActivity}': 'mg_85_slack_moon',
 'ComponentInfo{com.Slack/slack.features.home.HomeActivity}': 'mg_85_slack_moon',
 'ComponentInfo{notion.id/notion.local.id.MainActivity}': 'mg_86_notion_moon',
 'ComponentInfo{com.canva.editor/com.canva.app.editor.splash.SplashActivity}': 'mg_87_canva_moon',
 'ComponentInfo{com.lemon.lvoverseas/com.vega.main.MainActivity}': 'mg_88_capcut_moon',
 'ComponentInfo{com.lemon.lvoverseas/com.vega.launcher.precondition.PreInstallConfirmActivity}': 'mg_88_capcut_moon',
 'ComponentInfo{com.adobe.reader/com.adobe.reader.AdobeReader}': 'mg_89_adobe_acrobat_moon',
 'ComponentInfo{com.dropbox.android/com.dropbox.android.activity.DropboxBrowser}': 'mg_90_dropbox_moon',
 'ComponentInfo{com.google.android.apps.translate/com.google.android.apps.translate.TranslateActivity}': 'mg_91_google_translate_moon',
 'ComponentInfo{com.google.android.apps.translate/com.google.android.apps.translate.HomeActivity}': 'mg_91_google_translate_moon',
 'ComponentInfo{com.ubercab/com.ubercab.presidio.app.core.root.RootActivity}': 'mg_97_uber_moon',
 'ComponentInfo{com.airbnb.android/com.airbnb.android.activities.MainActivity}': 'mg_98_airbnb_moon',
 'ComponentInfo{com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.startup.activities.StartupActivity}': 'mg_99_paypal_moon',
 'ComponentInfo{com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.HubActivity}': 'mg_99_paypal_moon',
 'ComponentInfo{com.ebay.mobile/com.ebay.mobile.activities.MainActivity}': 'mg_100_ebay_moon',
 'ComponentInfo{com.ebay.mobile/com.ebay.mobile.activities.eBay}': 'mg_100_ebay_moon',
 'ComponentInfo{com.duolingo/com.duolingo.app.LoginActivity}': 'mg_101_duolingo_moon',
 'ComponentInfo{com.duolingo/com.duolingo.app.StreakSocietyLauncher}': 'mg_101_duolingo_moon',
 'ComponentInfo{org.thoughtcrime.securesms/org.thoughtcrime.securesms.RoutingActivity}': 'mg_102_signal_moon',
 'ComponentInfo{org.thoughtcrime.securesms/org.thoughtcrime.securesms.RoutingActivityAltWhite}': 'mg_102_signal_moon',
 'ComponentInfo{org.thoughtcrime.securesms/org.thoughtcrime.securesms.RoutingActivityAltColor}': 'mg_102_signal_moon',
 'ComponentInfo{org.thoughtcrime.securesms/org.thoughtcrime.securesms.RoutingActivityAltDark}': 'mg_102_signal_moon',
}
observed_entries = {item.attrib["component"]: item.attrib["drawable"] for item in filt.findall("item")}
assert all(observed_entries.get(k)==v for k,v in expected_additional.items()), "missing documented component reference"
for name in ('moon_lake.png','dream_clouds.png'):
    assert (root/'app/src/main/assets/wallpapers'/name).is_file()
print('PASS: 102 RGBA PNG headers, 127 unique launcher mappings, 25 new gallery icons, paired XML catalogs, 102 gallery icons, required mappings, 2 wallpapers.')
