MOON GLASS GLOBAL CORE PATCH V4 — CUMULATIVE TEST PATCH

This archive contains the full previous v3 document mapping plus 23 additional launcher-component entries across 17 named app groups. Total item entries: 94.

Added: Google Search, Google Meet (including legacy Duo), Google Keep, Samsung SmartThings, Galaxy Store, Galaxy Wearable, Facebook Messenger, Netflix, TikTok, Firefox, Edge, Brave, Discord, Snapchat, Amazon Shopping and Zoom.

The artwork is intentionally generic and copyright-independent, using the existing 40 Moon Glass PNGs. Different services may share the same generic category icon. This is a COVERAGE TEST patch, not finished commercial artwork. For a finished icon pack, produce distinctive original designs for major apps instead of using the same icon for every app category.

Component references were cross-checked against publicly available icon-pack appfilter maps; they are historical candidates, not confirmed components on all current device/app versions. An icon is verified only after a user sees it AND taps it successfully on their device.

GitHub workflow: replace only the previous patch archive filename after `unzip -o -q` with Moon_Glass_Global_Core_Patch_v4.zip. This archive is cumulative; do not separately extract older patches afterward. Keep the original base project archive.

Technical note: the current workflow runs `python3 tools/check_assets.py` BEFORE extracting the patch, so that job-level check does not inspect the patched filter. A later maintenance change should place patch extraction before asset verification. This ZIP is independently checked for well-formed identical appfilters, unique components, and existing drawable references.
