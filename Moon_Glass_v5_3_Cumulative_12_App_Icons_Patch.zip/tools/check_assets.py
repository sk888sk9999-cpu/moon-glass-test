"""Moon Glass v5.3: standard-library static checks run after the cumulative v5 patch overlay."""
from pathlib import Path
from xml.etree import ElementTree as ET
import struct, re
root = Path(__file__).resolve().parents[1]
icons = sorted((root/'app/src/main/res/drawable-nodpi').glob('mg_*.png'))
assert len(icons) == 52, f'Expected 52 icons, found {len(icons)}'
for icon in icons:
    data = icon.read_bytes()
    assert data[:8] == b'\x89PNG\r\n\x1a\n', f'Not a PNG: {icon}'
    w,h,depth,color = struct.unpack('>IIBB',data[16:26])
    assert (w,h,depth,color) == (1024,1024,8,6), (icon,w,h,depth,color)
known = {icon.stem for icon in icons}
assert len(known) == 52
for base in ('app/src/main/res/xml/','app/src/main/assets/'):
    catalogue=ET.parse(root/base/'drawable.xml').getroot()
    items=catalogue.findall('item')
    drawings=[item.attrib['drawable'] for item in items]
    assert len(drawings) == 52 and set(drawings) == known, ('catalogue',base)
    filt=ET.parse(root/base/'appfilter.xml').getroot()
    entries=filt.findall('item')
    assert len(entries) == 94, ('launcher count',base,len(entries))
    comps=[item.attrib['component'] for item in entries]
    assert len(comps) == len(set(comps)), ('duplicate components',base)
    for item in entries:
        assert item.attrib['drawable'] in known, item.attrib
        assert item.attrib['component'].startswith('ComponentInfo{'), item.attrib
assert (root/'app/src/main/res/xml/appfilter.xml').read_bytes() == (root/'app/src/main/assets/appfilter.xml').read_bytes()
assert (root/'app/src/main/res/xml/drawable.xml').read_bytes() == (root/'app/src/main/assets/drawable.xml').read_bytes()
main = (root/'app/src/main/java/com/moonglass/iconpack/test/MainActivity.java').read_text(encoding='utf-8')
gallery=re.findall(r'R\.drawable\.(mg_[a-z0-9_]+)',main)
assert len(gallery) == 52 and set(gallery) == known, ('gallery mismatch',len(gallery))
required={
 'com.skt.prod.dialer':'mg_01_phone',
 'word.office.docxviewer.document.docx.reader':'mg_16_notes',
 'com.google.android.googlequicksearchbox':'mg_34_search',
 'com.samsung.android.oneconnect':'mg_38_connection',
 'com.google.android.youtube':'mg_41_youtube_moon',
 'com.netflix.mediaclient':'mg_42_netflix_moon',
 'com.zhiliaoapp.musically':'mg_43_tiktok_moon',
 'com.whatsapp':'mg_44_whatsapp_moon',
 'com.discord':'mg_45_discord_moon',
 'com.android.vending':'mg_46_play_store_moon',
 'com.sec.android.app.samsungapps':'mg_47_galaxy_store_moon',
 'com.google.android.apps.docs.editors.docs':'mg_48_docs_moon',
 'com.google.android.gm':'mg_52_gmail_moon',
 'org.telegram.messenger':'mg_51_telegram_moon',
 'com.spotify.music':'mg_50_spotify_moon',
 'com.instagram.android':'mg_49_instagram_moon',
}
filt=ET.parse(root/'app/src/main/res/xml/appfilter.xml').getroot()
for pkg,icon in required.items():
    assert any(item.attrib['component'].startswith('ComponentInfo{'+pkg+'/') and item.attrib['drawable']==icon for item in filt.findall('item')),('missing mapping',pkg,icon)
for name in ('moon_lake.png','dream_clouds.png'):
    assert (root/'app/src/main/assets/wallpapers'/name).is_file()
print('PASS: 52 RGBA PNG headers, 94 unique launcher mappings, paired XML catalogs, 52 gallery icons, required mappings, 2 wallpapers.')
