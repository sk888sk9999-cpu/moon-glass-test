Moon Glass v5.5 — Slack mapping addendum (2026-09-22)

Apply AFTER the 5 v5.5 Mobile Small Part ZIPs; do not replace those ZIPs.
Adds exactly ONE Slack launcher-component candidate:
  ComponentInfo{com.Slack/slack.features.home.HomeActivity} -> mg_85_slack_moon
Keeps the original Slack candidate and all other 126 component mappings unchanged.
Updates both appfilter.xml copies identically and changes tools/check_assets.py to expect 127 mappings.
No PNG, gallery or wallpaper is modified.

Evidence: a Samsung launcher app-list record dated 2025-12-22 lists this component for Slack:
https://gist.github.com/DariaAzur/722ca0dd66460ced2ce0247fd24d341a
A 2024 Android launcher log contains the same component:
https://github.com/medic/cht-android/issues/357
These are dated observations, NOT verification for Slack's September 2026 APK or the user's device.
PayPal unchanged: no verified MAIN + LAUNCHER manifest evidence for its newer MainActivity.

GitHub Actions workflow: append after the fifth v5.5 unzip command:
  unzip -o -q Moon_Glass_v5_5_Slack_Mapping_Addendum.zip
Before running python3 tools/check_assets.py.
