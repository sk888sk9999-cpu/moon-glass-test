Moon Glass v5.5 — cumulative 25-app global expansion plus documented appfilter mappings.

APPLY: unzip Moon_Glass_Galaxy_Test_Mobile_Upload.zip, then THIS ZIP. Do NOT overlay earlier v5.1–v5.4 patch ZIPs. v5.4 never required a separate build. Prior brand artwork and 40 base generic PNG files unchanged.

ASSETS: 40 base generics + 62 individual brand-design PNGs = 102 actual 1024×1024 RGBA PNGs. The new 25 from v5.5 are mg_78–mg_102. Their images, gallery, names, and drawable XML are unchanged from the earlier v5.5 candidate.

MAPPINGS: Retains all 94 v5.4/v5.5 preexisting mappings. Adds 32 public/reference-derived component strings for the 20 v5.5 apps formerly gallery-only; all 25 new v5.5 apps now have at least one candidate appfilter component (the five browser/music/office references from initial candidate are preserved). Both appfilter XML files are identical. Total: 126 distinct component entries.

IMPORTANT: This is reference-based auto-mapping coverage, NOT real-device proof. Older community references may no longer match app launcher activities on current APKs; icon-pack support depends on the launcher and app version. The supplied appfilter.xml points only to icons; it does NOT change app launch intents or guarantee app compatibility. None of these 20 target apps was installed or tested on the user's device for v5.5. See MOON_GLASS_V5_5_MAPPING_AUDIT.tsv for every component and source.

VERIFICATION: ZIP integrity, 102 PNG header and dimensions, both paired appfilter/drawable XML, retained 94 mapping byte-identical dictionary, expected 20 app group references, 102 gallery icons and two wallpapers validated locally on original base project. GitHub Actions APK build and phone application NOT YET verified.

This icon artwork references app names solely to describe icon targets; no affiliation, endorsement, license, or trademark clearance is claimed.
