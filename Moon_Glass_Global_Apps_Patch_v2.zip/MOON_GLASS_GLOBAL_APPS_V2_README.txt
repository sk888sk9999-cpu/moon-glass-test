Moon Glass Global Apps Mapping Patch v2 (TEST ONLY)
==================================================
Scope: only the two appfilter.xml files are replaced. No new icon art, brand logos,
wallpapers, build files, package name, or signing key changes. Existing 36 mappings
(including the already device-tested SKT A. Dot Dialer, Play Store, Samsung Contacts
and Samsung Calculator) are retained.

INSTALLATION INTO GITHUB WORKFLOW:
1. Keep Moon_Glass_Galaxy_Test_Mobile_Upload.zip in repository root.
2. Upload this ZIP in repository root, do not unpack on your phone.
3. Open .github/workflows/build-from-upload.yml.
4. In the Extract project run block, REPLACE ONLY the previous patch filename:
   Moon_Glass_Global_Mapping_Patch.zip  -->  Moon_Glass_Global_Apps_Patch_v2.zip
5. Commit changes; the automatic build produces a new test APK.

This is an incremental mapping test for international app categories: messaging,
music, video, photos, files, documents, fitness, books, tasks and wallet.
Category-symbol icons are generic, and no brand logos are copied. Several entries
are known from older public appfilter examples and might not match a current
launcher activity; app-specific Android updates can also change component names.
Neither successful compilation nor inclusion in this ZIP proves device coverage.

Not included: bespoke icon drawings for NAVER/Word/Health; these apps receive generic
category symbols where matching works. More distinct icons can be designed later.

Component-source examples (for checking candidate activity paths):
- https://github.com/amirzaidi/GoogleIcons/blob/master/app/src/main/res/xml/appfilter.xml
- https://iconpusher.com/package/com.google.android.apps.messaging
- https://iconpusher.com/package/com.spotify.music
- https://iconpusher.com/package/com.kakao.talk
- https://iconpusher.com/package/com.google.android.apps.docs.editors.docs
- https://iconpusher.com/package/com.google.android.apps.docs
- https://iconpusher.com/package/com.google.android.apps.youtube.creator
- https://iconpusher.com/package/com.google.android.apps.walletnfcrel
- https://github.com/cjycsm/mistiness-iconpack/blob/master/MistinessIconpack/app/src/main/assets/appfilter.xml
- https://gist.github.com/pascalwhoop/b4acf2ff9f22187d40990380c3be6308
