Moon Glass v5.2 — reference-calibrated brand icon candidate

This is a cumulative replacement for v5.1: apply ONLY this patch to the original base project ZIP.
Changes: replace 8 brand PNGs mg_41–mg_48 with eight independently generated icons, normalize their visible tile footprint to approximately 868 px on a 1024 x 1024 transparent RGBA canvas, and moderate darker-blue/violet pixels toward the existing generic set. The background glass, symbol and ornaments are in the source artwork; the image correction does NOT isolate or independently shrink the interior glyph.
All appfilter and drawable XML mappings, gallery metadata, MainActivity and asset checks are byte-identical to v5.1. Generic icons mg_01–mg_40 remain in the original base ZIP, untouched.
Status: local automated project asset validation complete; Android APK build, real-phone application, and user visual approval NOT performed. Some visual differences in symbol weight remain possible.
