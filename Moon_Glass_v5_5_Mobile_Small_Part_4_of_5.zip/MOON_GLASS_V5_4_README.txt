Moon Glass v5.4 — global 25-app expansion

Cumulative patch over Moon_Glass_Galaxy_Test_Mobile_Upload.zip ONLY. Do not additionally unzip earlier v5.x patches. Adds 25 original Moon Glass-styled 1024x1024 RGBA PNG icons (mg_53–mg_77), preserving all 52 v5.3 icons and the original 40 generics. Changes exactly 25 previously known global app package mappings in paired appfilters, preserving 94 unique launcher components. Adds all 25 to gallery and names.

Brand-independent custom letter + feature motifs, not official app logos. This is an icon theme experiment; names identify target apps, not affiliation. Existing component-to-app mappings are sourced from the preceding appfilter; actual class names may vary by version, device, region, or launcher.

Validation: local static checks. Android APK build and actual phone application of this revision are NOT verified until new GitHub Actions build and device test.
